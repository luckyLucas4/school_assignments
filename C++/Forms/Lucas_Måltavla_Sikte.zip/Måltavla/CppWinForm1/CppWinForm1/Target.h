#pragma once
using namespace System::Drawing;
ref class Target 
{
public:
	// Deklarerar variabler
	float x, y, radius, parts;
	// K�rs n�r f�nstret ska ritas om
	void Draw(Graphics^ g) {
		// Pennan anv�nds f�r att rita kanten p� m�ltavlan
		Pen^ pen = gcnew Pen(Color::Black,5);

		// Penseln som ritar ringarna
		SolidBrush^ b = gcnew SolidBrush(Color::White);

		// Ett f�lt med f�rger som kan anv�ndas till penseln
		array<Color>^ colors = { Color::DarkRed, Color::Yellow, Color::Red, Color::Blue, Color::Black, Color::Aquamarine, Color::SandyBrown, Color::DarkSalmon, Color::Brown, Color::Green, Color::Orange, Color::MediumSpringGreen, Color::Bisque, Color::PaleGreen, Color::Turquoise, Color::Sienna};

		// Rektangeln d�r cirkeln ska ritas
		Rectangle^ drawTarget = gcnew Rectangle(
			this->x,
			this->y,
			(2 * this->radius),
			(2 * this->radius));

		// Ritar den svarta kanten och den yttersta vita ringen
		g->DrawEllipse(pen, drawTarget->X, drawTarget->Y, drawTarget->Width, drawTarget->Height);
		g->FillEllipse(b, drawTarget->X, drawTarget->Y, drawTarget->Width, drawTarget->Height);

		// Loopar en g�ng f�r varje cirkel som ska ritas
		for (int i = (int)(this->parts - 1); i > 0; i--)
		{
			// Koordinaterna f�r ringen flyttas �t h�ger och ned�t varje g�ng loopen k�rs 
			// justerat efter antalet ringar
			drawTarget->X += this->radius * 1/this->parts;
			drawTarget->Y += this->radius * 1/this->parts;
			// Radien minskar baserat p� antalet ringar som ska ritas
			drawTarget->Width = this->radius * 2 * (float)(i / this->parts);
			drawTarget->Height = drawTarget->Width;
			// Penseln f�r n�sta f�rg i f�ltet
			b->Color = colors[i-1];
			// Cirkeln ritas med de nya v�rdena som nu har satts
			g->FillEllipse(b, drawTarget->X, drawTarget->Y, drawTarget->Width, drawTarget->Height);
		}
	}
};