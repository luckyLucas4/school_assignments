#pragma once
#include "Target.h";
#include "Aim.h"

namespace CppWinForm1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^  pcbTarget;

	protected:

	protected:




	private: System::Windows::Forms::NumericUpDown^  numRadius;
	private: System::Windows::Forms::TrackBar^  trackBarX;
	private: System::Windows::Forms::TrackBar^  trackBarY;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::NumericUpDown^  numRings;

	private: System::Windows::Forms::Label^  label2;


	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->pcbTarget = (gcnew System::Windows::Forms::PictureBox());
			this->numRadius = (gcnew System::Windows::Forms::NumericUpDown());
			this->trackBarX = (gcnew System::Windows::Forms::TrackBar());
			this->trackBarY = (gcnew System::Windows::Forms::TrackBar());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->numRings = (gcnew System::Windows::Forms::NumericUpDown());
			this->label2 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pcbTarget))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numRadius))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBarX))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBarY))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numRings))->BeginInit();
			this->SuspendLayout();
			// 
			// pcbTarget
			// 
			this->pcbTarget->Enabled = false;
			this->pcbTarget->Location = System::Drawing::Point(214, 135);
			this->pcbTarget->Name = L"pcbTarget";
			this->pcbTarget->Size = System::Drawing::Size(414, 409);
			this->pcbTarget->TabIndex = 0;
			this->pcbTarget->TabStop = false;
			this->pcbTarget->Visible = false;
			// 
			// numRadius
			// 
			this->numRadius->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numRadius->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) { 10, 0, 0, 0 });
			this->numRadius->Location = System::Drawing::Point(12, 54);
			this->numRadius->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1000, 0, 0, 0 });
			this->numRadius->Name = L"numRadius";
			this->numRadius->Size = System::Drawing::Size(79, 38);
			this->numRadius->TabIndex = 5;
			this->numRadius->ValueChanged += gcnew System::EventHandler(this, &MyForm::numRadius_ValueChanged);
			// 
			// trackBarX
			// 
			this->trackBarX->Location = System::Drawing::Point(111, 17);
			this->trackBarX->Maximum = 730;
			this->trackBarX->Name = L"trackBarX";
			this->trackBarX->Size = System::Drawing::Size(659, 56);
			this->trackBarX->SmallChange = 10;
			this->trackBarX->TabIndex = 6;
			this->trackBarX->TickFrequency = 0;
			this->trackBarX->Value = 85;
			this->trackBarX->Scroll += gcnew System::EventHandler(this, &MyForm::trackBarX_Scroll);
			// 
			// trackBarY
			// 
			this->trackBarY->Location = System::Drawing::Point(24, 191);
			this->trackBarY->Maximum = 700;
			this->trackBarY->Minimum = 80;
			this->trackBarY->Name = L"trackBarY";
			this->trackBarY->Orientation = System::Windows::Forms::Orientation::Vertical;
			this->trackBarY->RightToLeft = System::Windows::Forms::RightToLeft::Yes;
			this->trackBarY->Size = System::Drawing::Size(56, 452);
			this->trackBarY->SmallChange = 10;
			this->trackBarY->TabIndex = 7;
			this->trackBarY->TickFrequency = 0;
			this->trackBarY->Value = 700;
			this->trackBarY->Scroll += gcnew System::EventHandler(this, &MyForm::trackBarY_Scroll);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(19, 17);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(74, 25);
			this->label1->TabIndex = 8;
			this->label1->Text = L"Radie:";
			// 
			// numRings
			// 
			this->numRings->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->numRings->Location = System::Drawing::Point(24, 135);
			this->numRings->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 15, 0, 0, 0 });
			this->numRings->Name = L"numRings";
			this->numRings->Size = System::Drawing::Size(56, 30);
			this->numRings->TabIndex = 9;
			this->numRings->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 6, 0, 0, 0 });
			this->numRings->ValueChanged += gcnew System::EventHandler(this, &MyForm::numRings_ValueChanged);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(21, 105);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(63, 20);
			this->label2->TabIndex = 10;
			this->label2->Text = L"Ringar:";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(782, 655);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->numRings);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->trackBarY);
			this->Controls->Add(this->trackBarX);
			this->Controls->Add(this->numRadius);
			this->Controls->Add(this->pcbTarget);
			this->DoubleBuffered = true;
			this->KeyPreview = true;
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"MyForm";
			this->Text = L"M�ltavla";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &MyForm::MyForm_KeyDown);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pcbTarget))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numRadius))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBarX))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBarY))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numRings))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	// Deklarerar instanser av klasserna Target och Aim

	Target^ target = gcnew Target();
	Aim^ playerAim = gcnew Aim();

	// K�rs direkt n�r programmet startar
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {

		// S�tter koordinaterna p� m�ltavlan till samma som bildrutan, 
		target->x = pcbTarget->Location.X;
		target->y = pcbTarget->Location.Y;

		// och justerar dragreglagen till de v�rdena
		trackBarX->Value = (int)target->x;		
		trackBarY->Value = 700 - (int)target->y; // (dras fr�n maxv�rdet s� att reglaget startar vid toppen)

		// Radien justeras efter bildrutan, nummerv�ljaren tar emot det v�rdet
		target->radius = pcbTarget->Size.Height/2;
		int x = target->radius;
		numRadius->Value = x;

		// Antalet ringar justeras efter nummerv�ljarens v�rde
		target->parts = (float)numRings->Value;

		// Startpositionen f�r siktet
		playerAim->x = 400;
		playerAim->y = 350;
	}

	public: virtual System::Void MyForm::OnPaint(PaintEventArgs^ e) override {
		// N�r sk�rmen ska ritas kallar programmet p� klassernas egna funktioner
		target->Draw(e->Graphics);
		playerAim->Draw(e->Graphics);
	}

	private: System::Void numRadius_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		// Nummerv�ljaren �ndrar m�ltavlans radie
		target->radius = (float)numRadius->Value;
		// och f�nstret ritas om
		Invalidate();
	}

	private: System::Void trackBarX_Scroll(System::Object^  sender, System::EventArgs^  e) {
		// X-koordinaten justeras efter det �vre dragreglaget
		target->x = (float)(trackBarX->Value);
		Invalidate();
	}

	private: System::Void trackBarY_Scroll(System::Object^  sender, System::EventArgs^  e) {
		// Y-koordinaten justeras efter det v�nstra dragreglaget (inverterat pga 700 - v�rdet)
		target->y = 700 - (float)(trackBarY->Value);
		Invalidate();
	}

	private: System::Void numRings_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		// Den nedre nummerv�ljaren �ndrar antalet ringar
		target->parts = (float)numRings->Value;
		Invalidate();
	}
	
	private: System::Void MyForm_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		// Anropar funktionen KeyDown i siktet
		if (playerAim->KeyDown(e)) {
			// F�nstret ritas bara om ifall koordinaten har �ndrats
			Invalidate();

		}
	}

	
};
}
