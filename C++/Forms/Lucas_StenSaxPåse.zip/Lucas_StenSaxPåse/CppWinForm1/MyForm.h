#pragma once
#include <cstdlib>
namespace CppWinForm1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnSax;
	protected:

	private: System::Windows::Forms::Button^  btnSten;
	private: System::Windows::Forms::Button^  btnP�se;
	protected:


	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  lblVinnare;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  lblSpelare;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  lblDator;
	private: System::Windows::Forms::PictureBox^  pcbPaper;
	private: System::Windows::Forms::PictureBox^  pcbRock;
	private: System::Windows::Forms::PictureBox^  pcbScissors;




	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->btnSax = (gcnew System::Windows::Forms::Button());
			this->btnSten = (gcnew System::Windows::Forms::Button());
			this->btnP�se = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->lblVinnare = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->lblSpelare = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->lblDator = (gcnew System::Windows::Forms::Label());
			this->pcbPaper = (gcnew System::Windows::Forms::PictureBox());
			this->pcbRock = (gcnew System::Windows::Forms::PictureBox());
			this->pcbScissors = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pcbPaper))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pcbRock))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pcbScissors))->BeginInit();
			this->SuspendLayout();
			// 
			// btnSax
			// 
			this->btnSax->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnSax->Location = System::Drawing::Point(55, 158);
			this->btnSax->Name = L"btnSax";
			this->btnSax->Size = System::Drawing::Size(78, 63);
			this->btnSax->TabIndex = 0;
			this->btnSax->Text = L"Sax";
			this->btnSax->UseVisualStyleBackColor = true;
			this->btnSax->Click += gcnew System::EventHandler(this, &MyForm::btnSax_Click);
			// 
			// btnSten
			// 
			this->btnSten->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnSten->Location = System::Drawing::Point(56, 86);
			this->btnSten->Name = L"btnSten";
			this->btnSten->Size = System::Drawing::Size(77, 56);
			this->btnSten->TabIndex = 1;
			this->btnSten->Text = L"Sten";
			this->btnSten->UseVisualStyleBackColor = true;
			this->btnSten->Click += gcnew System::EventHandler(this, &MyForm::btnSten_Click);
			// 
			// btnP�se
			// 
			this->btnP�se->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnP�se->Location = System::Drawing::Point(55, 237);
			this->btnP�se->Name = L"btnP�se";
			this->btnP�se->Size = System::Drawing::Size(77, 58);
			this->btnP�se->TabIndex = 1;
			this->btnP�se->Text = L"P�se";
			this->btnP�se->UseVisualStyleBackColor = true;
			this->btnP�se->Click += gcnew System::EventHandler(this, &MyForm::btnP�se_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(68, 35);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(56, 25);
			this->label1->TabIndex = 2;
			this->label1->Text = L"V�lj:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(237, 35);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(71, 25);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Dator:";
			// 
			// lblVinnare
			// 
			this->lblVinnare->AutoSize = true;
			this->lblVinnare->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblVinnare->Location = System::Drawing::Point(207, 149);
			this->lblVinnare->Name = L"lblVinnare";
			this->lblVinnare->Size = System::Drawing::Size(133, 25);
			this->lblVinnare->TabIndex = 4;
			this->lblVinnare->Text = L"Vem vinner\?";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(212, 196);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(96, 25);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Statistik:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(181, 246);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(36, 20);
			this->label4->TabIndex = 6;
			this->label4->Text = L"Du:";
			// 
			// lblSpelare
			// 
			this->lblSpelare->AutoSize = true;
			this->lblSpelare->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblSpelare->Location = System::Drawing::Point(223, 246);
			this->lblSpelare->Name = L"lblSpelare";
			this->lblSpelare->Size = System::Drawing::Size(18, 20);
			this->lblSpelare->TabIndex = 7;
			this->lblSpelare->Text = L"0";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(272, 246);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(56, 20);
			this->label5->TabIndex = 8;
			this->label5->Text = L"Dator:";
			// 
			// lblDator
			// 
			this->lblDator->AutoSize = true;
			this->lblDator->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblDator->Location = System::Drawing::Point(334, 246);
			this->lblDator->Name = L"lblDator";
			this->lblDator->Size = System::Drawing::Size(18, 20);
			this->lblDator->TabIndex = 9;
			this->lblDator->Text = L"0";
			// 
			// pcbPaper
			// 
			this->pcbPaper->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pcbPaper.BackgroundImage")));
			this->pcbPaper->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pcbPaper->Location = System::Drawing::Point(226, 77);
			this->pcbPaper->Name = L"pcbPaper";
			this->pcbPaper->Size = System::Drawing::Size(91, 64);
			this->pcbPaper->TabIndex = 10;
			this->pcbPaper->TabStop = false;
			this->pcbPaper->Visible = false;
			// 
			// pcbRock
			// 
			this->pcbRock->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pcbRock.BackgroundImage")));
			this->pcbRock->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pcbRock->Location = System::Drawing::Point(229, 77);
			this->pcbRock->Name = L"pcbRock";
			this->pcbRock->Size = System::Drawing::Size(87, 64);
			this->pcbRock->TabIndex = 11;
			this->pcbRock->TabStop = false;
			this->pcbRock->Visible = false;
			// 
			// pcbScissors
			// 
			this->pcbScissors->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pcbScissors.BackgroundImage")));
			this->pcbScissors->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pcbScissors->Location = System::Drawing::Point(226, 77);
			this->pcbScissors->Name = L"pcbScissors";
			this->pcbScissors->Size = System::Drawing::Size(90, 64);
			this->pcbScissors->TabIndex = 12;
			this->pcbScissors->TabStop = false;
			this->pcbScissors->Visible = false;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(379, 322);
			this->Controls->Add(this->pcbScissors);
			this->Controls->Add(this->pcbRock);
			this->Controls->Add(this->pcbPaper);
			this->Controls->Add(this->lblDator);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->lblSpelare);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->lblVinnare);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnP�se);
			this->Controls->Add(this->btnSten);
			this->Controls->Add(this->btnSax);
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pcbPaper))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pcbRock))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pcbScissors))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnSten_Click(System::Object^  sender, System::EventArgs^  e) {
		int random = rand() % 3;
		int num;
		switch (random)
		{
		case 0:
			pcbRock->Visible = true;
			pcbScissors->Visible = false;
			pcbPaper->Visible = false;
			lblVinnare->Text = "Oavgjort!";
			break;
		case 1:
			pcbRock->Visible = false;
			pcbScissors->Visible = true;
			pcbPaper->Visible = false;
			lblVinnare->Text = "Du vann!";
			num = Convert::ToInt32(lblSpelare->Text);
			num++;
			lblSpelare->Text = Convert::ToString(num);
			break;
		case 2:
			pcbRock->Visible = false;
			pcbScissors->Visible = false;
			pcbPaper->Visible = true;
			lblVinnare->Text = "Datorn vann!";
			num = Convert::ToInt32(lblDator->Text);
			num++;
			lblDator->Text = Convert::ToString(num);
		default:
			break;
		}
	}
	private: System::Void btnSax_Click(System::Object^  sender, System::EventArgs^  e) {
		int random = rand() % 3;
		int num;
		switch (random)
		{
		case 0:
			pcbRock->Visible = true;
			pcbScissors->Visible = false;
			pcbPaper->Visible = false;
			lblVinnare->Text = "Datorn vann!";
			num = Convert::ToInt32(lblDator->Text);
			num++;
			lblDator->Text = Convert::ToString(num);
			break;
		case 1:
			pcbRock->Visible = false;
			pcbScissors->Visible = true;
			pcbPaper->Visible = false;
			lblVinnare->Text = "Oavgjort!";

			break;
		case 2:
			pcbRock->Visible = false;
			pcbScissors->Visible = false;
			pcbPaper->Visible = true;
			lblVinnare->Text = "Du vann!";
			num = Convert::ToInt32(lblSpelare->Text);
			num++;
			lblSpelare->Text = Convert::ToString(num);
		default:
			break;
		}
	}
	private: System::Void btnP�se_Click(System::Object^  sender, System::EventArgs^  e) {
		int random = rand() % 3;
		int num;
		switch (random)
		{
		case 0:
			pcbRock->Visible = true;
			pcbScissors->Visible = false;
			pcbPaper->Visible = false;

			lblVinnare->Text = "Du vann!";
			num = Convert::ToInt32(lblSpelare->Text);
			num++;
			lblSpelare->Text = Convert::ToString(num);
			break;
		case 1:
			pcbRock->Visible = false;
			pcbScissors->Visible = true;
			pcbPaper->Visible = false;

			lblVinnare->Text = "Datorn vann!";
			num = Convert::ToInt32(lblDator->Text);
			num++;
			lblDator->Text = Convert::ToString(num);
			break;
		case 2:
			pcbRock->Visible = false;
			pcbScissors->Visible = false;
			pcbPaper->Visible = true;
			lblVinnare->Text = "Oavgjort!";
			break;
		default:
			break;
		}
	}
};
}
