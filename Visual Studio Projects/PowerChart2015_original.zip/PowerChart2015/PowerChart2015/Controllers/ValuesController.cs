﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Globalization;
using Google.DataTable.Net.Wrapper;
using PowerChart2015.Models;

namespace PowerChart2015.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public string Get()
        {
            return Get(-1);
        }

        // GET api/values/5
        public string Get(int year)
        {
            IEnumerable<DataPoint> dataSerie = Enumerable.Empty<DataPoint>();

            //Läs in filen!
            dataSerie = ReadFile();

            //Filtrera ev. på år.
            if (year > 0)
            {
                dataSerie = FilterByYear(year, dataSerie);
            }

            //Omforma data till Google DataTable
            var jsonData = ConvertToGoogleDataTable(dataSerie);

            //Returnera data till webbsidan
            return jsonData;
        }

        #region Other API  methods
        // POST api/values
        public void Post([FromBody]string value)
        {
            throw new NotImplementedException();
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
            throw new NotImplementedException();
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
            throw new NotImplementedException();
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Läser in allt data från filen ~/App_Data/F30116.csv och skapar en lista av datatypen DataPoint.
        /// </summary>
        /// <returns>Lista av datatypen DataPoint</returns>
        private IEnumerable<DataPoint> ReadFile()
        {
            List<DataPoint> list = new List<DataPoint>();
            var filePath = HttpContext.Current.Request.MapPath(@"~/App_Data/F30116.csv");

            if (!File.Exists(filePath))
            {
                list.Add(new DataPoint() { Date = new DateTime(2015, 1, 1), Value = 13d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 2, 1), Value = 12d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 3, 1), Value = 10d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 4, 1), Value = 8d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 5, 1), Value = 7d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 6, 1), Value = 4d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 7, 1), Value = 3d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 8, 1), Value = 5d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 9, 1), Value = 7d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 10, 1), Value = 7d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 11, 1), Value = 9d });
                list.Add(new DataPoint() { Date = new DateTime(2015, 12, 1), Value = 11d });
            }
            else
            {
                int i = 0;
                foreach(string line in File.ReadLines(filePath))
                {
                    if (i != 0)
                    {
                        var lineContent = line.Split(',');
                        DateTime date;
                        if (!DateTime.TryParse(lineContent[1], out date))
                            date = new DateTime(1980, 1, 1);
                        Double value;
                        if (!Double.TryParse(lineContent[2], NumberStyles.Number, CultureInfo.CreateSpecificCulture("en-US"), out value))
                            value = 0d;
                        list.Add(new DataPoint() { Date = date, Value = value });
                    }
                    i++;
                }
            }

            return list;
        }

        /// <summary>
        /// Filtrerar en lista av datatypen DataPoint utifrån det år som skickas in.
        /// </summary>
        /// <param name="year">Årtalet som ska filtreras</param>
        /// <param name="data">Listan som ska filtreras</param>
        /// <returns>Den filtrerade listan.</returns>
        private IEnumerable<DataPoint> FilterByYear(int year, IEnumerable<DataPoint> data)
        {
            if (data == null)
                return Enumerable.Empty<DataPoint>();
            else
                return data.Where(dp => dp.Date.Year == year);
        }

        /// <summary>
        /// Gör om listan med DataPoints till ett JSON-format som Google använder i sina grafer.
        /// </summary>
        /// <param name="dataSerie"></param>
        /// <returns>Sträng innehållandes allt data i Google DataTable-format.</returns>
        private string ConvertToGoogleDataTable(IEnumerable<DataPoint> dataSerie)
        {
            var dt = new Google.DataTable.Net.Wrapper.DataTable();
            dt.AddColumn(new Column(ColumnType.Datetime, "Date", "Datum"));
            dt.AddColumn(new Column(ColumnType.Number, "Consumption", "kWh"));
            foreach (var item in dataSerie)
            {
                Row r = dt.NewRow();
                r.AddCellRange(new Cell[]
                {
                    new Cell(item.Date),
                    new Cell(item.Value)
                });
                dt.AddRow(r);
            }
            
            var jsonData = dt.GetJson();

            return jsonData;
        }
        #endregion
    }
}
