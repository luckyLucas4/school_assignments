﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PowerChart2015.Models
{
    public class DataPoint
    {
        public DateTime Date { get; set; }
        public double Value { get; set; }

        public DataPoint() { }

        public DataPoint(DateTime date, double value)
        {
            Date = date;
            Value = value;
        }
    }
}