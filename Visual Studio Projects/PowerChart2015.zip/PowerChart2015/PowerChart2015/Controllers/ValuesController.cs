﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Runtime;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Globalization;
using Google.DataTable.Net.Wrapper;
using PowerChart2015.Models;

namespace PowerChart2015.Controllers
{
    public class ValuesController : ApiController
    {
        public string Get()
        {
            string mtrID = ReadMtrID();
            return mtrID;
        }
        // GET api/values/5
        public string Get(DateTime minDate, DateTime maxDate)
        {
            IEnumerable<DataPoint> dataSerie = Enumerable.Empty<DataPoint>();

            //Läs in filen
            var validUntil = HttpContext.Current.Cache["validUntil"] as DateTime?;
            if (validUntil != null && validUntil > DateTime.Now)
                dataSerie = HttpContext.Current.Cache["dataSerie"] as IEnumerable<DataPoint>;
            else
            {
                dataSerie = ReadFile();
                HttpContext.Current.Cache["dataSerie"] = dataSerie;
                HttpContext.Current.Cache["validUntil"] = DateTime.Now.AddDays(1);
            }

            //Filtrera på år.

            dataSerie = FilterByYear(minDate, maxDate, dataSerie);

            //Omforma data till Google DataTable
            var jsonData = ConvertToGoogleDataTable(dataSerie);

            //Returnera data till webbsidan
            return jsonData;
        }

        #region Other API  methods
        // POST api/values
        public void Post([FromBody]string value)
        {
            throw new NotImplementedException();
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
            throw new NotImplementedException();
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
            throw new NotImplementedException();
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Läser in allt data från filen ~/App_Data/F30116.csv och skapar en lista av datatypen DataPoint.
        /// </summary>
        /// <returns>Lista av datatypen DataPoint</returns>
        public IEnumerable<DataPoint> ReadFile()
        {
            List<DataPoint> list = new List<DataPoint>();

            // Kod för att öppna, läsa och plocka ut data från filen.
            string path = "~/App_Data/F30116.csv";
            string realPath = HttpContext.Current.Request.MapPath(path);
            //Sparar all info i en string
            
            string fullText = File.ReadAllText(realPath);

            //Delar infon i en array beroende på rader
            char[] splitParameters = { '\r', '\n' }; 
            string[] separatedLines = fullText.Split(splitParameters, StringSplitOptions.RemoveEmptyEntries);

            //Loopar igenom raderna
            for (int count = 0; count < separatedLines.Length; count++){
                //Hoppa till nästa rad om det är "beskrivningsraden"
                if (count == 0){
                    continue;
                }
                string line = separatedLines[count];
                //Delar upp raderna i de olika värdena
                string[] values = new string[line.Split(',').Length];
                values = line.Split(',');
                
                //Variabler att spara värden i
                DateTime date;
                double value;

                /*Försök konvertera de värden som behövs till rätt format 
                och lägga till dem som ett DataPoint objekt i listan*/
                try {
                    date = Convert.ToDateTime(values[1]);

                    value = Convert.ToDouble(values[2], CultureInfo.InvariantCulture.NumberFormat);
                    list.Add(new DataPoint(date, value));
                }
                //Fånga upp fel
                catch (Exception e) {
                    Console.WriteLine("Exception caught: {0}", e);
                }

                    
            }
            //Skicka tillbaks listan med DataPoint objekt
            return list;
        }

        private string ReadMtrID()
        {
            string mtrID = "";
            // Kod för att öppna, läsa och plocka ut data från filen.
            string path = "~/App_Data/F30116.csv";
            string realPath = HttpContext.Current.Request.MapPath(path);
            //Sparar all info i en string

            string fullText = File.ReadAllText(realPath);

            //Delar infon i en array beroende på rader
            char[] splitParameters = { '\r', '\n' };
            string[] separatedLines = fullText.Split(splitParameters, StringSplitOptions.RemoveEmptyEntries);

            //Loopar igenom raderna
            for (int count = 0; count < separatedLines.Length; count++)
            {
                //Hoppa till nästa rad om det är "beskrivningsraden"
                if (count == 0)
                {
                    continue;
                }
                string line = separatedLines[count];
                //Delar upp raderna i de olika värdena
                string[] values = new string[line.Split(',').Length];
                values = line.Split(',');
                if(!mtrID.Contains(values[0]))
                {
                    if(mtrID.Length > 0)
                    {
                        mtrID = mtrID + ",";
                    }
                    mtrID = mtrID + " " + values[0];
                }
                
            }
            return mtrID;
        }
        /// <summary>
        /// Filtrerar en lista av datatypen DataPoint utifrån det år som skickas in.
        /// </summary>
        /// <param name="year">Årtalet som ska filtreras</param>
        /// <param name="data">Listan som ska filtreras</param>
        /// <returns>Den filtrerade listan.</returns>
        private IEnumerable<DataPoint> FilterByYear(DateTime minDate, DateTime maxDate, IEnumerable<DataPoint> data)
        {
            // Eventuell kod för att filtrera på år.
            List<DataPoint> newData = new List<DataPoint>();
            foreach(var item in data)
            {
                if(item.Date >= minDate && item.Date <= maxDate)
                {
                    newData.Add(item);
                }
            }
            return newData;
        }

        /// <summary>
        /// Gör om listan med DataPoints till ett JSON-format som Google använder i sina grafer.
        /// </summary>
        /// <param name="dataSerie"></param>
        /// <returns>Sträng innehållandes allt data i Google DataTable-format.</returns>
        private string ConvertToGoogleDataTable(IEnumerable<DataPoint> dataSerie)
        {
            var dt = new Google.DataTable.Net.Wrapper.DataTable();

            // Kod för att konvertera data till Google DataTable-format.
            dt.AddColumn(new Column(ColumnType.Datetime, "År"));
            dt.AddColumn(new Column(ColumnType.Number, "Värde"));

            foreach (var item in dataSerie)
            {
                Row r = dt.NewRow();
                r.AddCellRange(new Cell[]{
                    new Cell(item.Date),
                    new Cell(item.Value)
                });
                dt.AddRow(r);
            }

            var jsonData = dt.GetJson();

            return jsonData;
        }
        #endregion
    }
}
